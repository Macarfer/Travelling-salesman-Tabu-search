gcc fileManager.c main.c tabuSearch.c -lm -o tabu
