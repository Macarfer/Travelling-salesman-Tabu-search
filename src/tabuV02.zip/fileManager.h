#include <stdio.h>
#include <stdlib.h>

#define DIMENSION 100
void openFile(const char * path,int matrix[DIMENSION][DIMENSION]);
double * openRandoms(const char *path);
